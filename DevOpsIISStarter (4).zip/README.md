# DevOps IIS Starter

A small ASP.NET Core 10 web application intended for learning Azure DevOps CI/CD and IIS deployment.

## What it includes
- A simple browser UI served from `wwwroot`
- `GET /health` endpoint for deployment health checks
- Azure Pipelines YAML to build and publish the application
- A PowerShell MSDeploy example for a separately configured IIS server

## Prerequisites
- .NET 10 SDK on the CI build agent
- IIS on the target Windows Server
- ASP.NET Core Hosting Bundle 10.x on the IIS server
- Web Deploy installed and configured on IIS if using the MSDeploy handler
- Network/firewall approval for the chosen deployment endpoint/port

## Run locally
```powershell
dotnet restore .\src\DevOpsIISStarter\DevOpsIISStarter.csproj
dotnet run --project .\src\DevOpsIISStarter\DevOpsIISStarter.csproj
```
Open the URL printed in the console. Visit `/health` to see the health response.

## Publish locally
```powershell
dotnet publish .\src\DevOpsIISStarter\DevOpsIISStarter.csproj -c Release -o .\publish
```

The publish output is a deployable ASP.NET Core application. Do not copy source files such as `.csproj` and `Program.cs` directly into the IIS website root.

## Azure DevOps
The included `azure-pipelines.yml` builds and publishes an artifact named `drop`. The deployment script is provided separately because your IIS endpoint, approved port, authentication and agent network access must be confirmed before enabling automatic deployment.

## IIS deployment notes
- Install the matching ASP.NET Core Hosting Bundle on IIS.
- Configure an IIS site/application whose physical path points to the deployment directory.
- Use a dedicated deployment identity with least privilege.
- Prefer a self-hosted deployment agent that has private network connectivity to IIS.
- If using WMSvc, the default Web Deploy endpoint is HTTPS on TCP 8172, but your company must approve the port. A custom WMSvc port can be configured by an administrator.
- Do not expose deployment ports to the public internet. Do not disable certificate validation in production.
- Store passwords as secret pipeline variables or a secure service connection; never commit secrets.

## Files
See `docs/FILE-GUIDE.md` for the purpose of every project file.
