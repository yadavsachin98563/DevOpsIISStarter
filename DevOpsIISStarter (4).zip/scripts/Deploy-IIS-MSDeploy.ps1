[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string] $PublishPath,

    [Parameter(Mandatory = $true)]
    [string] $IisHost,

    [Parameter(Mandatory = $true)]
    [string] $IisSite,

    [Parameter(Mandatory = $true)]
    [string] $DeployUser,

    [Parameter(Mandatory = $true)]
    [string] $DeployPassword,

    [int] $Port = 8172
)

$ErrorActionPreference = 'Stop'
$msdeploy = Join-Path $env:ProgramFiles 'IIS\Microsoft Web Deploy V3\msdeploy.exe'

if (-not (Test-Path -LiteralPath $msdeploy)) {
    throw "MSDeploy executable not found at '$msdeploy'. Install Web Deploy on the deployment agent."
}
if (-not (Test-Path -LiteralPath $PublishPath -PathType Container)) {
    throw "Published output folder not found: '$PublishPath'"
}

# WMSvc Handler uses HTTPS, even when a custom port is configured.
$endpoint = "https://${IisHost}:$Port/MSDeploy.axd?site=$IisSite"
$destination = "contentPath=`"$IisSite`",computerName=`"$endpoint`",userName=`"$DeployUser`",password=`"$DeployPassword`",authType=Basic"

& $msdeploy `
    '-verb:sync' `
    "-source:contentPath=$PublishPath" `
    "-dest:$destination" `
    '-enableRule:AppOffline'

if ($LASTEXITCODE -ne 0) {
    throw "MSDeploy failed with exit code $LASTEXITCODE"
}
Write-Host "MSDeploy completed successfully for IIS site '$IisSite'."
