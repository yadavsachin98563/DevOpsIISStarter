# File-by-file guide

## Repository root
- `DevOpsIISStarter.slnx`: modern Visual Studio solution container. The CLI can build the project directly via its `.csproj`.
- `global.json`: requests the .NET 10 SDK family for local development. If the exact SDK feature band is not installed, `rollForward: latestFeature` allows a newer feature band within the same major/minor SDK line.
- `.gitignore`: keeps build output, IDE files and local secrets out of Git.
- `README.md`: setup, run, publish, and IIS deployment notes.
- `azure-pipelines.yml`: CI pipeline: checkout, install SDK, restore, build, publish, and upload artifact `drop`.

## Application: `src/DevOpsIISStarter`
- `DevOpsIISStarter.csproj`: project metadata; `Microsoft.NET.Sdk.Web` enables ASP.NET Core web hosting; `net10.0` is the target framework.
- `Program.cs`: app startup, static file middleware, and `/health` JSON endpoint.
- `appsettings.json`: baseline logging and allowed-host settings.
- `appsettings.Development.json`: more verbose logging for local development only.
- `wwwroot/index.html`: the browser UI and explanation of the deployment steps.
- `wwwroot/css/site.css`: styling for the page.
- `wwwroot/js/site.js`: button handler that calls `/health` and displays the result.

## Deployment helper
- `scripts/Deploy-IIS-MSDeploy.ps1`: sample MSDeploy Handler deployment command. It syncs a `dotnet publish` output folder (`PublishPath`) to an existing IIS site. It expects the IIS hostname, site name, user, password and approved port. Do not run it until the firewall team approves the port and the IIS endpoint, credentials and certificate are configured. Password is passed as a process argument in this simple teaching example; for production, prefer a protected deployment mechanism/credential provider and a secret variable, and avoid verbose logging.

## Why there is no checked-in `web.config`
`dotnet publish` generates an IIS `web.config` for ASP.NET Core hosting when publishing the app. This generated file belongs in the publish artifact; do not hand-write one unless there is a specific hosting requirement.
