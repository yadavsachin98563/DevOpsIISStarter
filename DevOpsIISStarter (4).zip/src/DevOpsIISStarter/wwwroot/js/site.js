const button = document.querySelector("#healthButton");
const result = document.querySelector("#healthResult");

button?.addEventListener("click", async () => {
  result.textContent = "Checking /health ...";
  try {
    const response = await fetch("/health", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    result.textContent = `Status: ${data.status} · App: ${data.application} · UTC: ${data.timestampUtc}`;
  } catch (error) {
    result.textContent = `Health check failed: ${error.message}`;
  }
});
