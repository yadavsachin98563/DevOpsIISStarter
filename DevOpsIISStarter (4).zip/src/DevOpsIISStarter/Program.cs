var builder = WebApplication.CreateBuilder(args);

// Static files (HTML, CSS, JavaScript) are served from wwwroot.
var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

// Lightweight endpoint for a pipeline or load balancer health check.
app.MapGet("/health", () => Results.Ok(new
{
    status = "Healthy",
    application = "DevOpsIISStarter",
    version = "1.0.0",
    timestampUtc = DateTimeOffset.UtcNow
}));

app.Run();
